package com.reikoonya.musikoo.ui.components

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.reikoonya.musikoo.ui.theme.ShapeFamily
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Set by the theme. MD3 = plain rounded corners, Expensive = leaf corners for surfaces and stars/cookies for covers. */
object ShapeStyle {
    @Volatile
    var family: ShapeFamily = ShapeFamily.MD3E
}

/**
 * Shape for containers (cards, pills, sheets). Never cuts content: text stays inside.
 * Expensive uses soft leaf corners, circles only for the largest radii.
 */
fun shapeOf(radius: Dp): Shape = when {
    ShapeStyle.family == ShapeFamily.MD3 -> RoundedCornerShape(radius)
    radius >= 40.dp -> CircleShape
    else -> RoundedCornerShape(
        topStart = radius * 1.2f,
        topEnd = radius * 0.3f,
        bottomEnd = radius * 1.2f,
        bottomStart = radius * 0.3f,
    )
}

/**
 * Shape for cover art only: Expensive uses stars, cookies and circles.
 * Do not use for containers that hold text, the outline clips content.
 */
fun coverShapeOf(radius: Dp): Shape = when {
    ShapeStyle.family == ShapeFamily.MD3 -> RoundedCornerShape(radius)
    radius < 10.dp -> RoundedCornerShape(radius)
    radius < 22.dp -> ExpensiveStar
    radius < 40.dp -> ExpensiveCookie
    else -> CircleShape
}

private val ExpensiveStar: Shape = starShape(points = 6, innerRatio = 0.78f)
private val ExpensiveCookie: Shape = cookieShape(lobes = 9, depth = 0.07f)

private fun starShape(points: Int, innerRatio: Float): Shape = GenericShape { size, _ ->
    val cx = size.width / 2f
    val cy = size.height / 2f
    val outer = minOf(size.width, size.height) / 2f
    for (i in 0 until points * 2) {
        val r = if (i % 2 == 0) outer else outer * innerRatio
        val a = (PI * i / points - PI / 2).toFloat()
        val x = cx + r * cos(a)
        val y = cy + r * sin(a)
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

private fun cookieShape(lobes: Int, depth: Float): Shape = GenericShape { size, _ ->
    val cx = size.width / 2f
    val cy = size.height / 2f
    val base = minOf(size.width, size.height) / 2f
    val steps = 180
    for (i in 0..steps) {
        val t = (2 * PI * i / steps).toFloat()
        val r = base * (1f - depth + depth * cos(lobes * t))
        val x = cx + r * cos(t)
        val y = cy + r * sin(t)
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}
