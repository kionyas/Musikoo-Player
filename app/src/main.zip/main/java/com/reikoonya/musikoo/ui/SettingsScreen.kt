package com.reikoonya.musikoo.ui

import com.reikoonya.musikoo.ui.theme.FontChoice
import com.reikoonya.musikoo.ui.components.coverShapeOf
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.rounded.ChevronRight
import com.reikoonya.musikoo.ui.theme.ShapeFamily
import com.reikoonya.musikoo.ui.components.shapeOf
import androidx.compose.material.icons.rounded.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.reikoonya.musikoo.R
import com.reikoonya.musikoo.ui.components.ArtBackdrop
import com.reikoonya.musikoo.ui.components.TopFadeScrim
import com.reikoonya.musikoo.ui.components.bounceClickable
import com.reikoonya.musikoo.ui.components.cardFill
import com.reikoonya.musikoo.ui.components.glassFill
import com.reikoonya.musikoo.ui.components.glassStroke
import com.reikoonya.musikoo.ui.components.listItemColors
import com.reikoonya.musikoo.ui.components.nowPlayingArt
import com.reikoonya.musikoo.ui.theme.ColorThemeMode
import com.reikoonya.musikoo.ui.theme.UiStyle
import com.reikoonya.musikoo.util.AppIconMode

@Composable
fun SettingsScreen(
    onBackClick: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onRescanLibrary: () -> Unit,
    uiStyle: UiStyle,
    onUiStyleChange: (UiStyle) -> Unit,
    shapeFamily: ShapeFamily = ShapeFamily.MD3E,
    onShapeFamilyChange: (ShapeFamily) -> Unit = {},
    fontChoice: FontChoice = FontChoice.BASE,
    onFontChoiceChange: (FontChoice) -> Unit = {},
    colorThemeMode: ColorThemeMode,
    onColorThemeModeChange: (ColorThemeMode) -> Unit,
    appIconMode: AppIconMode,
    onAppIconModeChange: (AppIconMode) -> Unit,
    lastFmUser: String? = null,
    onLastFmConnect: () -> Unit = {},
    onLastFmDisconnect: () -> Unit = {}
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount ->
                    if (dragAmount > 25f) {
                        onBackClick()
                    }
                }
            }
    ) {
        ArtBackdrop(art = nowPlayingArt(), topScrim = 0.55f, midScrim = 0.82f)

        // Settings content filling entire screen and scrolling underneath floating top pill
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(modifier = Modifier.height(72.dp))

            // 1. Playback
            SettingsGroupHeader(title = stringResource(R.string.playback)) {
                SettingsCardItem(
                    icon = Icons.Rounded.Notifications,
                    title = stringResource(R.string.player_notifications),
                    description = stringResource(R.string.player_notifications_desc),
                    onClick = onRequestNotificationPermission
                )
            }

            // 2. Library
            SettingsGroupHeader(title = stringResource(R.string.library)) {
                SettingsCardItem(
                    icon = Icons.Rounded.Refresh,
                    title = stringResource(R.string.rescan_library),
                    description = stringResource(R.string.rescan_library_desc),
                    onClick = onRescanLibrary
                )
            }

            // Last.fm
            SettingsGroupHeader(title = "Last.fm") {
                if (lastFmUser == null) {
                    SettingsCardItem(
                        icon = Icons.Rounded.Link,
                        title = "Connect Last.fm",
                        description = "Send your listening history to your Last.fm account",
                        onClick = onLastFmConnect
                    )
                } else {
                    SettingsCardItem(
                        icon = Icons.Rounded.Link,
                        title = "Account: $lastFmUser",
                        description = "Tap to disconnect Last.fm",
                        onClick = onLastFmDisconnect
                    )
                }
            }

            // 3. Appearance
            SettingsGroupHeader(title = stringResource(R.string.appearance)) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingsCardItem(
                        icon = Icons.Rounded.Palette,
                        title = stringResource(R.string.color_theme),
                        description = "Current theme: ${
                            when (colorThemeMode) {
                                ColorThemeMode.DYNAMIC -> "Dynamic Color"
                                ColorThemeMode.CLASSIC -> "Classic Color"
                                ColorThemeMode.COVER -> "Cover Color"
                            }
                        }"
                    )

                    StyleOptionCard(
                        title = "Dynamic Color",
                        description = "System dynamic colors based on wallpaper (Material You)",
                        selected = colorThemeMode == ColorThemeMode.DYNAMIC,
                        onClick = { onColorThemeModeChange(ColorThemeMode.DYNAMIC) }
                    )
                    StyleOptionCard(
                        title = "Classic Color (White/Gray)",
                        description = "Monochrome classic color palette",
                        selected = colorThemeMode == ColorThemeMode.CLASSIC,
                        onClick = { onColorThemeModeChange(ColorThemeMode.CLASSIC) }
                    )
                    StyleOptionCard(
                        title = "Cover Color",
                        description = "Dynamic color scheme extracted from current playing track art",
                        selected = colorThemeMode == ColorThemeMode.COVER,
                        onClick = { onColorThemeModeChange(ColorThemeMode.COVER) }
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    SettingsCardItem(
                        icon = Icons.Rounded.AutoAwesome,
                        title = "Background",
                        description = "Current: ${
                            when (uiStyle) {
                                UiStyle.CLASSIC -> "Solid"
                                UiStyle.EXPENSIVE -> "Cover"
                            }
                        }"
                    )

                    StyleOptionCard(
                        title = "Solid",
                        description = "Solid material background",
                        selected = uiStyle == UiStyle.CLASSIC,
                        onClick = { onUiStyleChange(UiStyle.CLASSIC) }
                    )
                    StyleOptionCard(
                        title = "Cover",
                        description = "Dynamic blur by the cover",
                        selected = uiStyle == UiStyle.EXPENSIVE,
                        onClick = { onUiStyleChange(UiStyle.EXPENSIVE) }
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    SettingsCardItem(
                        icon = Icons.Rounded.AutoAwesome,
                        title = "Shapes",
                        description = "Current: ${if (shapeFamily == ShapeFamily.MD3) "Material 3" else "Expensive"}"
                    )

                    StyleOptionCard(
                        title = "Material 3",
                        description = "Standard rounded corners",
                        selected = shapeFamily == ShapeFamily.MD3,
                        onClick = { onShapeFamilyChange(ShapeFamily.MD3) }
                    )
                    StyleOptionCard(
                        title = "Expensive",
                        description = "Mixed stars, cookies and circles",
                        selected = shapeFamily == ShapeFamily.MD3E,
                        onClick = { onShapeFamilyChange(ShapeFamily.MD3E) }
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    SettingsCardItem(
                        icon = Icons.Rounded.AutoAwesome,
                        title = "Font",
                        description = "Current: ${if (fontChoice == FontChoice.LORA) "Lora (adaptive)" else "Base"}"
                    )
                    StyleOptionCard(
                        title = "Base",
                        description = "System font",
                        selected = fontChoice == FontChoice.BASE,
                        onClick = { onFontChoiceChange(FontChoice.BASE) }
                    )
                    StyleOptionCard(
                        title = "Lora (adaptive)",
                        description = "Serif Lora, scales with the text size",
                        selected = fontChoice == FontChoice.LORA,
                        onClick = { onFontChoiceChange(FontChoice.LORA) }
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    SettingsCardItem(
                        icon = Icons.Rounded.AppShortcut,
                        title = stringResource(R.string.app_icon),
                        description = "Current icon: ${
                            when (appIconMode) {
                                AppIconMode.BLACK_WHITE -> "Black & White"
                                AppIconMode.WHITE_BLACK -> "White & Black"
                                AppIconMode.ONET -> "Monet"
                            }
                        }"
                    )

                    StyleOptionCard(
                        title = "Black & White",
                        description = "Minimalist dark icon (Default)",
                        selected = appIconMode == AppIconMode.BLACK_WHITE,
                        onClick = { onAppIconModeChange(AppIconMode.BLACK_WHITE) }
                    )
                    StyleOptionCard(
                        title = "White & Black",
                        description = "Light high-contrast icon",
                        selected = appIconMode == AppIconMode.WHITE_BLACK,
                        onClick = { onAppIconModeChange(AppIconMode.WHITE_BLACK) }
                    )
                    StyleOptionCard(
                        title = "Monet",
                        description = "Monet aesthetic dynamic icon",
                        selected = appIconMode == AppIconMode.ONET,
                        onClick = { onAppIconModeChange(AppIconMode.ONET) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // iOS-style top fade scrim
        TopFadeScrim(modifier = Modifier.align(Alignment.TopCenter))

        // Floating Top Bar Pill
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier
                    .size(44.dp)
                    .bounceClickable { onBackClick() },
                shape = CircleShape,
                color = glassFill(),
                border = glassStroke(),
                tonalElevation = 2.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = stringResource(R.string.back),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Surface(
                shape = shapeOf(32.dp),
                color = glassFill(),
                border = glassStroke()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(28.dp)
                            .height(3.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.settings),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.size(44.dp))
        }
    }
}

@Composable
fun SettingsScreen(
    onBackClick: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onRescanLibrary: () -> Unit,
    uiStyle: UiStyle,
    onUiStyleChange: (UiStyle) -> Unit
) = SettingsScreen(
    onBackClick = onBackClick,
    onRequestNotificationPermission = onRequestNotificationPermission,
    onRescanLibrary = onRescanLibrary,
    uiStyle = uiStyle,
    onUiStyleChange = onUiStyleChange,
    colorThemeMode = ColorThemeMode.DYNAMIC,
    onColorThemeModeChange = {},
    appIconMode = AppIconMode.BLACK_WHITE,
    onAppIconModeChange = {}
)

@Composable
fun SettingsScreen(
    onBackClick: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onRescanLibrary: () -> Unit,
    expressiveStyle: Boolean,
    onExpressiveStyleChange: (Boolean) -> Unit
) = SettingsScreen(
    onBackClick = onBackClick,
    onRequestNotificationPermission = onRequestNotificationPermission,
    onRescanLibrary = onRescanLibrary,
    uiStyle = if (expressiveStyle) UiStyle.EXPENSIVE else UiStyle.CLASSIC,
    onUiStyleChange = { newStyle -> onExpressiveStyleChange(newStyle != UiStyle.CLASSIC) },
    colorThemeMode = ColorThemeMode.DYNAMIC,
    onColorThemeModeChange = {},
    appIconMode = AppIconMode.BLACK_WHITE,
    onAppIconModeChange = {}
)

@Composable
private fun SettingsGroupHeader(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 12.dp, bottom = 2.dp)
        )
        content()
    }
}

@Composable
private fun SettingsCardItem(
    icon: ImageVector,
    title: String,
    description: String,
    onClick: (() -> Unit)? = null
) {
    // Each item gets its own badge shape (cookie, star or circle), so the list does not look like identical cards
    val badgeShape = when (kotlin.math.abs(title.hashCode()) % 3) {
        0 -> coverShapeOf(28.dp)
        1 -> coverShapeOf(16.dp)
        else -> CircleShape
    }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.bounceClickable { onClick() } else it },
        shape = shapeOf(32.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 0.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(badgeShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(26.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (onClick != null) {
                Icon(
                    imageVector = Icons.Rounded.ChevronRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun StyleOptionCard(
    title: String,
    description: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shapeOf(26.dp))
            .bounceClickable(onClick = onClick),
        shape = shapeOf(26.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else cardFill(),
        border = if (selected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)) else glassStroke(),
        tonalElevation = if (selected) 2.dp else 1.dp
    ) {
        ListItem(
            colors = listItemColors(),
            headlineContent = { Text(title, fontWeight = FontWeight.SemiBold) },
            supportingContent = { Text(description) },
            leadingContent = {
                RadioButton(
                    selected = selected,
                    onClick = null,
                    colors = RadioButtonDefaults.colors(
                        selectedColor = MaterialTheme.colorScheme.primary,
                        unselectedColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            },
            trailingContent = {
                if (selected) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
            }
        )
    }
}
