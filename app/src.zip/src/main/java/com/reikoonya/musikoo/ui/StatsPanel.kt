package com.reikoonya.musikoo.ui

import androidx.compose.ui.draw.rotate
import androidx.compose.material3.Icon
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.Icons
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.expandVertically
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.reikoonya.musikoo.scrobble.PlayRecord
import com.reikoonya.musikoo.scrobble.Scrobbler
import com.reikoonya.musikoo.ui.components.BounceSurface
import com.reikoonya.musikoo.ui.components.cardFill
import com.reikoonya.musikoo.ui.components.glassStroke
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** What the main screen shows under the pill. */
enum class MainMode(val label: String) {
    Library("Home"),
    Stats("Statistics")
}

/**
 * Compact mode selector in the top pill: shows the current mode and an arrow.
 * Tapping it expands downward to show the other options.
 */
@Composable
fun MainModeSwitch(mode: MainMode, onModeChange: (MainMode) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val arrowRotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        label = "modeArrow",
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        BounceSurface(
            onClick = { expanded = !expanded },
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.primaryContainer
        ) {
            Row(
                modifier = Modifier.padding(start = 12.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = mode.label,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.width(2.dp))
                Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(18.dp).rotate(arrowRotation)
                )
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier.padding(top = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MainMode.entries.filter { it != mode }.forEach { option ->
                    BounceSurface(
                        onClick = {
                            expanded = false
                            onModeChange(option)
                        },
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh
                    ) {
                        Text(
                            text = option.label,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

enum class StatsPeriod(val label: String, val phrase: String, val days: Int?) {
    Week("7 days", "for 7 days", 7),
    Month("30 days", "for 30 days", 30),
    All("All time", "for all time", null)
}

private data class Summary(
    val plays: Int,
    val listenedMs: Long,
    val topArtists: List<Pair<String, Int>>,
    val topTracks: List<Pair<String, Int>>,
)

private fun summarize(records: List<PlayRecord>, period: StatsPeriod, nowSec: Long): Summary {
    val from = period.days?.let { nowSec - (it * 86_400L) } ?: Long.MIN_VALUE
    val filtered = records.filter { it.timestamp >= from }
    return Summary(
        plays = filtered.size,
        listenedMs = filtered.sumOf { it.listenedMs },
        topArtists = filtered.groupingBy { it.artist }.eachCount()
            .entries.sortedByDescending { it.value }.take(5).map { it.key to it.value },
        topTracks = filtered.groupingBy { "${it.artist} — ${it.title}" }.eachCount()
            .entries.sortedByDescending { it.value }.take(5).map { it.key to it.value },
    )
}

private fun formatListened(ms: Long): String {
    val totalMinutes = ms / 60_000
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
}

/** Statistics screen: how much and what you listened to. Data comes from the local log and works without Last.fm. */
@Composable
fun StatsPanel(
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier,
) {
    val version by Scrobbler.playsVersion.collectAsState()
    var period by rememberSaveable { mutableStateOf(StatsPeriod.Week) }
    var records by remember { mutableStateOf<List<PlayRecord>>(emptyList()) }

    LaunchedEffect(version) {
        records = withContext(Dispatchers.IO) { Scrobbler.loadPlays() }
    }

    val summary = remember(records, period) {
        summarize(records, period, System.currentTimeMillis() / 1000)
    }
    val topArtistMax = summary.topArtists.maxOfOrNull { it.second }?.coerceAtLeast(1) ?: 1
    val topTrackMax = summary.topTracks.maxOfOrNull { it.second }?.coerceAtLeast(1) ?: 1

    LazyColumn(
        modifier = modifier,
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatsPeriod.entries.forEach { p ->
                    FilterChip(
                        selected = period == p,
                        onClick = { period = p },
                        label = { Text(p.label) }
                    )
                }
            }
        }

        item {
            GlassCard(title = null) {
                Text(
                    text = formatListened(summary.listenedMs),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "${summary.plays} listens ${period.phrase}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            GlassCard(title = "Top artists") {
                if (summary.topArtists.isEmpty()) {
                    EmptyHint()
                } else {
                    summary.topArtists.forEachIndexed { index, (name, count) ->
                        RankRow(index + 1, name, count, topArtistMax)
                    }
                }
            }
        }

        item {
            GlassCard(title = "Top tracks") {
                if (summary.topTracks.isEmpty()) {
                    EmptyHint()
                } else {
                    summary.topTracks.forEachIndexed { index, (label, count) ->
                        RankRow(index + 1, label, count, topTrackMax)
                    }
                }
            }
        }

        item {
            val user = remember { Scrobbler.username() }
            GlassCard(title = "Last.fm") {
                Text(
                    text = if (user != null) {
                        "Listens are sent to the account $user."
                    } else {
                        "Not connected. Connect Last.fm in Settings and your listens will be sent there."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun GlassCard(title: String?, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = cardFill()),
        border = glassStroke()
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(18.dp)) {
            if (title != null) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
            content()
        }
    }
}

@Composable
private fun RankRow(rank: Int, label: String, count: Int, max: Int) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = rank.toString(),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.width(24.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "$count",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { count.toFloat() / max },
            modifier = Modifier.fillMaxWidth().padding(start = 32.dp)
        )
    }
}

@Composable
private fun EmptyHint() {
    Text(
        text = "Nothing here yet. A track counts once half of it has played (and it is longer than 30 seconds).",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
