package com.reikoonya.musikoo.ui.components

import androidx.compose.material.icons.rounded.*
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.reikoonya.musikoo.ui.theme.LocalFancyStyle

/**
 * Play/Pause button with a spring animation in both themes: the shape morphs between a circle and a pill
 * (paused) and a rounded square (playing), and it springs in when pressed.
 * Sizes are configurable: large in the player, small in the mini player.
 */
@Composable
fun ExpressivePlayButton(
    isPlaying: Boolean,
    onClick: () -> Unit,
    containerColor: Color,
    contentColor: Color,
    modifier: Modifier = Modifier,
    width: Dp = 72.dp,
    height: Dp = 72.dp,
    size: Dp? = null,
    iconSize: Dp = 32.dp,
    playingCorner: Dp = 22.dp,
    idleCorner: Dp? = null,
) {
    val actualWidth = size ?: width
    val actualHeight = size ?: height
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()

    val popScale by animateFloatAsState(
        targetValue = if (pressed) 0.90f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "playPop"
    )

    val targetCorner = if (isPlaying) playingCorner else (idleCorner ?: (actualHeight / 2))
    val targetWidth = if (isPlaying) actualWidth else actualHeight

    val corner by animateDpAsState(
        targetValue = targetCorner,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "playCorner"
    )
    val currentWidth by animateDpAsState(
        targetValue = if (pressed) targetWidth * 0.9f else targetWidth,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "playWidth"
    )
    val currentHeight by animateDpAsState(
        targetValue = if (pressed) actualHeight * 0.9f else actualHeight,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "playHeight"
    )

    Surface(
        onClick = onClick,
        modifier = modifier
            .size(width = currentWidth, height = currentHeight)
            .graphicsLayer {
                scaleX = popScale
                scaleY = popScale
            },
        shape = RoundedCornerShape(corner),
        color = containerColor,
        contentColor = contentColor,
        interactionSource = interaction
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            MorphPlayPauseIcon(
                isPlaying = isPlaying,
                size = iconSize,
                contentDescription = if (isPlaying) "Pause" else "Play"
            )
        }
    }
}

/**
 * Настоящий морфинг play <-> pause: треугольник «распадается» на две планки (и обратно),
 * точки полигонов плавно интерполируются пружиной.
 */
@Composable
fun MorphPlayPauseIcon(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    tint: Color = LocalContentColor.current,
    contentDescription: String? = null,
) {
    val p by animateFloatAsState(
        targetValue = if (isPlaying) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "playPauseMorph"
    )
    val desc = contentDescription
    Canvas(
        modifier = modifier
            .size(size)
            .semantics { if (desc != null) this.contentDescription = desc }
            .graphicsLayer {
                // лёгкий «поворот» в момент перехода
                rotationZ = (1f - kotlin.math.abs(2f * p - 1f)) * 8f
            }
    ) {
        val s = this.size.minDimension
        fun mix(a: Float, b: Float) = a + (b - a) * p
        fun poly(vararg pts: Float): Path {
            val path = Path()
            for (i in 0 until 4) {
                val x = mix(pts[i * 4], pts[i * 4 + 2]) * s
                val y = mix(pts[i * 4 + 1], pts[i * 4 + 3]) * s
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            return path
        }
        // каждая точка: (xPlay, yPlay, xPause, yPause)
        val left = poly(
            0.22f, 0.12f, 0.24f, 0.14f,
            0.50f, 0.30f, 0.42f, 0.14f,
            0.50f, 0.70f, 0.42f, 0.86f,
            0.22f, 0.88f, 0.24f, 0.86f
        )
        val right = poly(
            0.50f, 0.30f, 0.58f, 0.14f,
            0.82f, 0.50f, 0.76f, 0.14f,
            0.82f, 0.50f, 0.76f, 0.86f,
            0.50f, 0.70f, 0.58f, 0.86f
        )
        val round = Stroke(width = s * 0.07f, join = StrokeJoin.Round)
        for (path in listOf(left, right)) {
            drawPath(path, tint, style = Fill)
            drawPath(path, tint, style = round)
        }
    }
}

/** Secondary button (back, forward, ±10 seconds, menu) with a spring press animation. */
@Composable
fun GlassIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = 56.dp,
    height: Dp = 52.dp,
    iconSize: Dp = 26.dp,
    shape: Shape = shapeOf(22.dp),
    containerColor: Color = glassFill(),
    contentColor: Color = MaterialTheme.colorScheme.onSurface,
    /** In plain M3, draw just the icon without a container (as before). */
    bareWhenClassic: Boolean = false,
) {
    val interaction = remember { MutableInteractionSource() }

    if (bareWhenClassic && !LocalFancyStyle.current) {
        IconButton(
            onClick = onClick,
            modifier = modifier
                .size(width = width, height = height)
                .pressScale(interaction),
            interactionSource = interaction
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                modifier = Modifier.size(iconSize),
                tint = contentColor
            )
        }
        return
    }

    Surface(
        onClick = onClick,
        modifier = modifier
            .size(width = width, height = height)
            .pressScale(interaction),
        shape = shape,
        color = containerColor,
        contentColor = contentColor,
        border = null,
        interactionSource = interaction
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                modifier = Modifier.size(iconSize)
            )
        }
    }
}