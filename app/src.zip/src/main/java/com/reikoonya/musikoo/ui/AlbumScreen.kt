package com.reikoonya.musikoo.ui

import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.runtime.saveable.rememberSaveable
import com.reikoonya.musikoo.ui.components.AnimatedFilterChips
import com.reikoonya.musikoo.ui.components.ChipOption
import com.reikoonya.musikoo.ui.components.ScreenTopBar
import com.reikoonya.musikoo.ui.components.SearchNoResults
import com.reikoonya.musikoo.ui.components.matchesQuery
import com.reikoonya.musikoo.ui.components.rememberScreenSearchState
import com.reikoonya.musikoo.ui.components.staggeredEntrance
import com.reikoonya.musikoo.ui.components.swipeDownToBack
import com.reikoonya.musikoo.ui.components.TopPill
import com.reikoonya.musikoo.ui.components.expressiveBadgeShape
import com.reikoonya.musikoo.ui.components.shapeOf
import com.reikoonya.musikoo.ui.components.rememberPersistentLazyGridState
import androidx.compose.material.icons.rounded.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.reikoonya.musikoo.R
import com.reikoonya.musikoo.ui.components.ActionsDialog
import com.reikoonya.musikoo.ui.components.ArtBackdrop
import com.reikoonya.musikoo.ui.components.MenuAction
import com.reikoonya.musikoo.ui.components.TopFadeScrim
import com.reikoonya.musikoo.ui.components.topFadeBlur
import com.reikoonya.musikoo.ui.components.bounceCombinedClickable
import com.reikoonya.musikoo.ui.components.bounceClickable
import com.reikoonya.musikoo.ui.components.cardFill
import com.reikoonya.musikoo.ui.components.glassFill
import com.reikoonya.musikoo.ui.components.glassStroke
import com.reikoonya.musikoo.ui.components.listItemColors
import com.reikoonya.musikoo.ui.components.nowPlayingArt
import com.reikoonya.musikoo.model.Song

@Composable
fun AlbumsScreen(
    songs: List<Song>,
    onAlbumClick: (String) -> Unit,
    onSongsEdited: (List<Song>) -> Unit = {},
    onBackClick: () -> Unit
) {
    val albums = remember(songs) { songs.groupBy { it.album } }
    var sortName by rememberSaveable { mutableStateOf(AlbumSort.AZ.name) }
    val sort = AlbumSort.valueOf(sortName)
    val search = rememberScreenSearchState()
    val shownAlbums = remember(albums, sort, search.query) {
        val filtered = albums.entries.filter { (name, list) ->
            matchesQuery(search.query, name, list.firstOrNull()?.artist, list.firstOrNull()?.albumArtist)
        }
        when (sort) {
            AlbumSort.AZ -> filtered.sortedBy { it.key.lowercase() }
            AlbumSort.MOST -> filtered.sortedByDescending { it.value.size }
            AlbumSort.ARTIST -> filtered.sortedWith(
                compareBy<Map.Entry<String, List<Song>>> { it.value.firstOrNull()?.artist.orEmpty().lowercase() }
                    .thenBy { it.key.lowercase() }
            )
        }
    }

    var actionsAlbum by remember { mutableStateOf<String?>(null) }
    var editSongs by remember { mutableStateOf<List<Song>?>(null) }

    actionsAlbum?.let { name ->
        ActionsDialog(
            title = name,
            actions = listOf(
                MenuAction(Icons.Rounded.Edit, stringResource(R.string.edit_tags)) {
                    editSongs = albums[name].orEmpty()
                    actionsAlbum = null
                }
            ),
            onDismiss = { actionsAlbum = null }
        )
    }
    editSongs?.let { list ->
        TagEditorDialog(
            songs = list,
            onDismiss = { editSongs = null },
            onSaved = onSongsEdited
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .swipeDownToBack(onBackClick)
    ) {
        ArtBackdrop(art = nowPlayingArt(), topScrim = 0.55f, midScrim = 0.82f)

        LazyVerticalGrid(
            state = rememberPersistentLazyGridState("albums"),
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize().topFadeBlur(),
            contentPadding = PaddingValues(top = 92.dp, bottom = 24.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                AnimatedFilterChips(
                    options = listOf(
                        ChipOption(AlbumSort.AZ, "A–Z"),
                        ChipOption(AlbumSort.MOST, "Most tracks"),
                        ChipOption(AlbumSort.ARTIST, "Artist"),
                    ),
                    selected = sort,
                    onSelect = { sortName = it.name }
                )
            }

            if (shownAlbums.isEmpty() && search.filtering) {
                item(span = { GridItemSpan(maxLineSpan) }) { SearchNoResults(search.query) }
            }

            gridItemsIndexed(shownAlbums, key = { _, entry -> entry.key }) { index, (albumName, albumSongs) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateItem()
                        .staggeredEntrance(index, once = true)
                        .bounceCombinedClickable(shape = shapeOf(32.dp), onLongClick = { actionsAlbum = albumName }) { onAlbumClick(albumName) },
                    shape = shapeOf(32.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = cardFill()
                    ),
                    border = glassStroke()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            modifier = Modifier.size(80.dp),
                            shape = expressiveBadgeShape(0),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.Album,
                                    contentDescription = null,
                                    modifier = Modifier.size(40.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = albumName,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = stringResource(R.string.tracks_count, albumSongs.size),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Top gradient scrim
        TopFadeScrim(modifier = Modifier.align(Alignment.TopCenter), blurred = true)

        ScreenTopBar(
            title = stringResource(R.string.albums_count, albums.size),
            onBack = onBackClick,
            search = search,
            searchHint = "Search albums",
            modifier = Modifier.align(Alignment.TopCenter)
        )
    }
}

private enum class AlbumSort { AZ, MOST, ARTIST }
