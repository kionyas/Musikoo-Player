package com.reikoonya.playeerok

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.reikoonya.playeerok.data.loadAudioFiles
import com.reikoonya.playeerok.ui.AlbumsScreen
import com.reikoonya.playeerok.ui.MainMenuScreen
import com.reikoonya.playeerok.ui.MenuSection
import com.reikoonya.playeerok.ui.PlayerScreen
import com.reikoonya.playeerok.ui.SongsScreen
import com.reikoonya.playeerok.ui.theme.PlayeerokTheme

sealed class Screen {
    object MainMenu : Screen()
    object Songs : Screen()
    object Albums : Screen()
    object Settings : Screen()
    data class Player(val songIndex: Int) : Screen()
}

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { isGranted ->
        if (isGranted) {
            recreate()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkAndRequestAudioPermission()

        setContent {
            PlayeerokTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.surface,
                ) {
                    val context = LocalContext.current
                    var songs by remember { mutableStateOf(loadAudioFiles(context)) }
                    var currentScreen by remember { mutableStateOf<Screen>(Screen.MainMenu) }

                    when (val screen = currentScreen) {
                        is Screen.MainMenu -> {
                            MainMenuScreen(
                                songs = songs,
                            ) { section ->
                                currentScreen = when (section) {
                                    MenuSection.Songs -> Screen.Songs
                                    MenuSection.Albums -> Screen.Albums
                                    MenuSection.Artists -> Screen.Songs
                                    MenuSection.Settings -> Screen.Settings
                                }
                            }
                        }
                        is Screen.Songs -> {
                            SongsScreen(
                                songs = songs,
                                onSongClick = { index -> currentScreen = Screen.Player(index) },
                            ) { currentScreen = Screen.MainMenu }
                        }
                        is Screen.Albums -> {
                            AlbumsScreen(
                                songs = songs,
                                onAlbumClick = { _ ->
                                    currentScreen = Screen.Songs
                                },
                            ) { currentScreen = Screen.MainMenu }
                        }
                        is Screen.Player -> {
                            PlayerScreen(
                                songs = songs,
                                initialSongIndex = screen.songIndex,
                            ) {
                                currentScreen = Screen.Songs
                            }
                        }
                        is Screen.Settings -> {
                            Surface(modifier = Modifier.fillMaxSize()) {
                                Box(contentAlignment = Alignment.Center) {
                                    Button(onClick = { currentScreen = Screen.MainMenu }) {
                                        Text("Назад в меню (Настройки в разработке)")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun checkAndRequestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(permission)
        }
    }
}