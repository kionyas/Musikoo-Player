# 1.6.1

## New
- Customizable gestures, bottom navigation bar and more
- Lots of new settings

## Improved
- Quality-of-life improvements across the app

## Fixed
- Bug fixes and performance optimizations